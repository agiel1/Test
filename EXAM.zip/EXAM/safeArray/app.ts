class SafeArray1 {
  private arr: number[] = [];
  private size: number = 5;
  private failed: number = 0;
  private failed_array: number[] = [];

  putElement(index: number, value: number) {
    if (index < 0 || index >= this.size) {
      this.failed++;
      this.failed_array.push(index);
      console.log(
        `not a valid index: ${this.failed} and indexs are ${this.failed_array}`
      );
    } else this.arr[index] = value;

    //this.arr.splice(index, 0, value);
  }
  getElement(index: number) {
    if (index < 0 || index >= this.size) {
      this.failed++;
      this.failed_array.push(index);
      console.log(
        `not a valid index: ${this.failed} and indexs are ${this.failed_array}`
      );
      return -1;
    } else return this.arr[index];
  }
}

let sa1 = new SafeArray1();
sa1.putElement(3, 20);
console.log(sa1.getElement(3));

sa1.putElement(13, 20);
sa1.putElement(40, 20);

sa1.getElement(42);

//console.log(sa1.getElement(3));

//     `No valid index:1 failed attempt and invalid attempts are ${index}`
//   );