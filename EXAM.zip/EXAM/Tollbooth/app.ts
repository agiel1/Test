class TollBooth {
  private static totalCars: number;
  private static totalMoney: number;
  constructor() {
    TollBooth.totalCars = 0;
    TollBooth.totalMoney = 0;
  }
  payingCar() {
    TollBooth.totalCars += 1;
    TollBooth.totalMoney += 50;
  }
  nonpaying() {
    TollBooth.totalCars += 1;
  }
  display() {
    console.log(TollBooth.totalCars, TollBooth.totalMoney);
  }

  get TotalCars(): number {
    return TollBooth.totalCars;
  }
  get TotalMoney(): number {
    return TollBooth.totalMoney;
  }
}
//sample("p", "n", "p", "p");
sample("p", "p", "n", "p", "p", "n", "p");
function sample(...data: string[]) {
  let obj = new TollBooth();
  data.forEach(function (item) {
    if (item == "p") obj.payingCar();
    if (item == "n") obj.nonpaying();
  });

  obj.display();
}