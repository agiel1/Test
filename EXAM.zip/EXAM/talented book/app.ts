interface Book {
    title: string;
    author: string;
  }
  
  const books: Book[] = [
    { title: "My Talented book", author: "ABC" },
    { title: "My Third Book", author: "XYZ" },
    { title: "First Book", author: "CDE" }
  ];
  
  function searchBooks(searchText: string): Book[] {
    searchText = searchText.toLowerCase();
    return books.filter(book => book.title.toLowerCase().indexOf(searchText) !== -1);
  }
  
  
  function handleSearchInput(event: Event): void {
    const searchInput = event.target as HTMLInputElement;
    const resultDiv = document.getElementById("resultDiv") as HTMLDivElement;
  
    const searchText = searchInput.value.trim();
    const searchResults = searchBooks(searchText);
  
    resultDiv.innerHTML = "";
    searchResults.forEach(book => {
      const bookDiv = document.createElement("div");
      bookDiv.textContent = `${book.title} - ${book.author}`;
      resultDiv.appendChild(bookDiv);
    });
  }
  
  const searchInput = document.getElementById("searchInput") as HTMLInputElement;
  searchInput.addEventListener("input", handleSearchInput);
  

  /*
  <!DOCTYPE html>
<html>
  <head>
    <title>Book Search</title>
    <script src="app.js" defer></script>
  </head>
  <body>
    <h1>Book Search</h1>

    <label for="searchInput">Search:</label>
    <input type="text" id="searchInput" />

    <div id="resultDiv"></div>
  </body>
</html>

  */