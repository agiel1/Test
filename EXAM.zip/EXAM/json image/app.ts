const products = [
    {"title": "Product 1" ,"image":"https://picsum.photos/200","price":380,"description":"First Product"},
    {"title": "Product 2" ,"image":"https://picsum.photos/200","price":980,"description":"Second Product"},
    {"title": "Product 3" ,"image":"https://picsum.photos/200","price":1200,"description":"Third Product"},
];

class Generate{
    renderDivs(products:any[]){
    const div = document.querySelector('#mainDiv') as HTMLDivElement;

    products.forEach(item =>{
    const productDiv = document.createElement("div");

    productDiv.innerHTML = `
    <h3>${item.title}</h3>
    <img src=${item.image}>
    <p>${item.price}</p>
    <p>${item.description}</p> 
    `
    div.appendChild(productDiv);
})
}
    renderProducts(products:any[]){
        const select = document.querySelector('#selectTag') as HTMLSelectElement;
        products.forEach(item =>{
            const productOption = document.createElement('option');
            productOption.value = item.title;
            productOption.innerText = item.title;
            select.appendChild(productOption);
        })
    }
    renderDivsSelected(products:any[],SelectedTitle:string){
        const div = document.querySelector('#mainDiv') as HTMLDivElement;
        div.innerHTML = "";
        products.forEach(item =>{
    if(item.title === SelectedTitle){
        const productDiv = document.createElement("div");
        productDiv.innerHTML = `
        <h3>${item.title}</h3>
        <img src=${item.image}>
        <p>${item.price}</p>
        <p>${item.description}</p> 
        `
        div.appendChild(productDiv);
    }        
})
        
    }
}

const generate = new Generate();
const options = document.querySelectorAll('option')
generate.renderDivs(products);
generate.renderProducts(products);
const select = document.querySelector('#selectTag') as HTMLSelectElement;
select.addEventListener('change',()=>{
    var e = select.options[select.selectedIndex].value;
    generate.renderDivsSelected(products,e);
})

/*
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
</head>

<body>
    <div id="mainDiv">
    </div>
    <select name="productDrop" id="selectTag"></select>
    <script src="app.js"></script>
</body>

</html>
*/