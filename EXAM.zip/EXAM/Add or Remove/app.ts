let input = document.querySelector("#in") as HTMLInputElement;
let deletion = document.querySelector("#del") as HTMLInputElement;
let div = document.querySelector("#div") as HTMLDivElement;
let p1 = document.createElement("p") as HTMLParagraphElement;
let p2 = document.createElement("p") as HTMLParagraphElement;
let arr: number[] = [];
function takeInput(): void {
  for (let i = 0; i < parseInt(input.value); i++) {
    let a = prompt()!;
    arr.push(parseInt(a));
  }
  p1.innerHTML = arr.toString();
  div.append(p1);
}

function deleteNo(): void {
  for (let i = 0; i < parseInt(deletion.value); i++) {
    let a = prompt()!;
    d(parseInt(a));
  }
  p2.innerHTML = arr.toString();
  div.append(p2);
}

function d(data): any {
  arr = arr.filter((item) => {
    return item != data;
  });
}

/*
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <script src="app.js"></script>
  </head>
  <body>
    enter no. of numbers for input :
    <input type="number" id="in" />
    <button id="input" onclick="takeInput()">input</button><br />
    enter no. of numbers for deletion:
    <input type="number" id="del" />
    <button id="input" onclick="deleteNo()">delete</button><br />
    <div id="div"></div>
    <script src="app.js"></script>
  </body>
</html>
*/