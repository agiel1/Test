"use strict";
console.log(`///----- Assignement - Array DOM Manupilation -----///`);
let arr = [];
const btn = document.querySelector("#btn");
const del = document.querySelector("#del");
const inpt = document.querySelector("#inpt");
const opt = document.querySelector("#opt");
const div = document.getElementById("app");
btn.addEventListener("click", (e) => {
    e.preventDefault();
    if (!inpt.value.trim()) {
        alert("No value entered");
        window.location.reload();
    }
    else {
        const _size = parseInt(inpt.value.trim());
        console.log(_size);
        for (let i = 1; i <= _size; i++) {
            const data = parseInt(prompt("Enter a number"));
            arr.push(data);
        }
        div.innerHTML = "";
        console.log(arr);
        arr.forEach((ele) => {
            div.innerText += `${ele}\n`;
        });
    }
    inpt.value = "";
});
del.addEventListener("click", (e) => {
    e.preventDefault();
    if (!opt.value.trim()) {
        alert("No value entered");
    }
    else if (arr.length === 0) {
        alert("Array is empty");
    }
    else {
        const _delSize = parseInt(opt.value.trim());
        let data;
        for (let i = 1; i <= _delSize; i++) {
            data = parseInt(prompt("Enter a number"));
            console.log(`Element to be deleted: ${data}`);
            const newArr = arr.filter((ele) => {
                return ele !== data;
            });
            if (newArr.length === arr.length) {
                alert(`Element not found!`);
            }
            else {
                arr = newArr.map((e) => e);
                console.log(newArr);
                div.innerHTML = "";
                newArr.forEach((ele) => {
                    div.innerText += `${ele}\n`;
                });
            }
        }
    }
    opt.value = "";
});
