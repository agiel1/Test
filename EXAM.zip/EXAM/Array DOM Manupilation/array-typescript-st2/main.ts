console.log(`///----- Assignement - Array DOM Manupilation -----///`);
let arr: number[] = [];
const btn = document.querySelector<HTMLButtonElement>("#btn")!;
const del = document.querySelector<HTMLButtonElement>("#del")!;
const inpt = document.querySelector("#inpt") as HTMLInputElement;
const opt = document.querySelector("#opt") as HTMLInputElement;
const div = document.getElementById("app") as HTMLDivElement;

btn.addEventListener("click", (e) => {
  e.preventDefault();
  if (!inpt.value.trim()) {
    alert("No value entered");
    window.location.reload();
  } else {
    const _size = parseInt(inpt.value.trim());
    console.log(_size);
    for (let i = 1; i <= _size; i++) {
      const data: number = parseInt(prompt("Enter a number")!)!;
      arr.push(data);
    }
    div.innerHTML = "";
    console.log(arr);
    arr.forEach((ele) => {
      div.innerText += `${ele}\n`;
    });
  }
  inpt.value = "";
});

del.addEventListener("click", (e) => {
  e.preventDefault();
  if (!opt.value.trim()) {
    alert("No value entered");
  } else if (arr.length === 0) {
    alert("Array is empty");
  } else {
    const _delSize = parseInt(opt.value.trim());
    let data: number;
    for (let i = 1; i <= _delSize; i++) {
      data = parseInt(prompt("Enter a number")!)!;
      console.log(`Element to be deleted: ${data}`);
      const newArr: number[] = arr.filter((ele) => {
        return ele !== data;
      });
      if (newArr.length === arr.length) {
        alert(`Element not found!`);
      } else {
        arr = newArr.map((e) => e);
        console.log(newArr);
        div.innerHTML = "";
        newArr.forEach((ele) => {
          div.innerText += `${ele}\n`;
        });
      }
    }
  }
  opt.value = "";
});
