interface ScheduleItem {
    [key: string]: string;
  }
  
  const scheduleData: ScheduleItem[] = [
    { "day 1": "Reach the destination" },
    { "day 2": "City Tour in a company tourist bus" },
    { "day 2": "Breakfast & Dinner" },
    { "day 3": "Visit Chang-La" },
    { "day 4": "Back to your home" }
  ];
  
  function displaySchedule(selectedDay: string | null): string[] {
    if (!selectedDay) {
      return [];
    }
  
    return scheduleData.reduce((content: string[], item) => {
      const day = Object.keys(item)[0];
      const description = item[day];
  
      if (day === selectedDay) {
        content.push(description);
      }
  
      return content;
    }, []);
  }
  
  const selectElement = document.getElementById("daySelect") as HTMLSelectElement;
  const contentDiv = document.getElementById("contentDiv") as HTMLDivElement;
  
  selectElement.addEventListener("change", () => {
    const selectedDay = selectElement.value;
    const selectedContent = displaySchedule(selectedDay);
  
    contentDiv.innerHTML = selectedContent.map(content => `<p>${content}</p>`).join("");
  });

  /*

  <!DOCTYPE html>
<html>
  <head>
    <title>Schedule Viewer</title>
  </head>
  <body>
    <h1>Schedule Viewer</h1>
    
    <label for="daySelect">Select Day:</label>
    <select id="daySelect">
      <option value="">-- Select Day --</option>
      <option value="day 1">Day 1</option>
      <option value="day 2">Day 2</option>
      <option value="day 3">Day 3</option>
      <option value="day 4">Day 4</option>
    </select>
    
    <div id="contentDiv"></div>
    
    <script src="app.js"></script>
  </body>
</html>

  */
  